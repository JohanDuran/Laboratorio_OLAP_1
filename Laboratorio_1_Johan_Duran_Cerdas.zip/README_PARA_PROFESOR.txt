SQL Server 2019
Visual Studio Community 2019
Capturas adjuntas de los resultados